import { Controller, Get, Render } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('examen.com')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  @Render('index')
  getHello() {
    const imageUrl = 'https://secadva.unach.mx/images/logo_unach.png'; 
    return { imageUrl };
  }
}

