import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { JjService } from './jj/jj.service';
import { JjModule } from './jj/jj.module';

@Module({
  imports: [JjModule],
  controllers: [AppController],
  providers: [AppService, JjService],
})
export class AppModule {}
