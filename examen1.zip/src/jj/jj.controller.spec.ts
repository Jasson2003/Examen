import { Test, TestingModule } from '@nestjs/testing';
import { JjController } from './jj.controller';

describe('JjController', () => {
  let controller: JjController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [JjController],
    }).compile();

    controller = module.get<JjController>(JjController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
