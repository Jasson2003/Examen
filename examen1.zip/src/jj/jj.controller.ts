import { Controller,Get, } from '@nestjs/common';
import { JjService } from './jj.service';
import { get } from 'http';

@Controller('jj')
export class JjController {
    constructor (private readonly servicej: JjService){}
    @Get()
    getArray():string []{
        return this.servicej.getArray();
    }
}


