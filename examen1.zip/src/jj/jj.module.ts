import { Module } from '@nestjs/common';
import { JjController } from './jj.controller';
import { JjService } from './jj.service';

@Module({
  controllers: [JjController],
  providers:[JjService]
})
export class JjModule {}
