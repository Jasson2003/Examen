import { Test, TestingModule } from '@nestjs/testing';
import { JjService } from './jj.service';

describe('JjService', () => {
  let service: JjService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [JjService],
    }).compile();

    service = module.get<JjService>(JjService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
