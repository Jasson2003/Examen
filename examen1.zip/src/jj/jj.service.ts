import { Injectable } from '@nestjs/common';

@Injectable()
export class JjService {
    getArray() : string[]{
        const jj : string []=['bicho', 'miguel'];
        return jj;
    }
}
